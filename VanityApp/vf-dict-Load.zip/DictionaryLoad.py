import json
import boto3
import os
import csv
import codecs
import sys

# Declaration Section
s3 = boto3.resource('s3')
dynamodb = boto3.resource('dynamodb')
key = 'VanityNumDict.csv' #this file should be already uploaded on bucket.
tableName = 'vf-dictionary' #Make sure table is not already created.
dynamodb = boto3.resource('dynamodb', region_name='eu-west-2')    

def lambda_handler(event, context):
   print(event)
   bucket = event['ResourceProperties']['Code']['S3Bucket']
   
   # Read csv file from s3Bucket
   try:
       obj = s3.Object(bucket, key).get()['Body']
   except:
       print('S3 Object could not be opened. Check environment variable. ')
   
   # block to create table with required partition and sort keys
   try:
       create_dynotble() 
   except Exception as err:
       print(err)
       print('Error loading DynamoDB table. Check if table was created correctly and environment variable.')

   batch_size = 100
   batch = []
   
   # Read csv file and pass to write_to_dynamo function in batch mode.
   for row in csv.DictReader(codecs.getreader('utf-8')(obj)):
      if len(batch) >= batch_size:
         write_to_dynamo(batch)
         batch.clear()
      batch.append(row)
   if batch:
      write_to_dynamo(batch)

   return {
      'statusCode': 200,
      'body': json.dumps('Uploaded to DynamoDB Table')
   }

# Creation of dynamodb table with error handling
def create_dynotble():
    table = dynamodb.create_table(
                TableName='vf-dictionary',
                KeySchema=[
                    {'AttributeName': 'Index', 'KeyType': 'HASH'},  # Partition key
                    {'AttributeName': 'Best', 'KeyType': 'RANGE'}  # Sort key
                ],
                AttributeDefinitions=[
                    {'AttributeName': 'Index', 'AttributeType': 'N'},
                    {'AttributeName': 'Best', 'AttributeType': 'S'}
                ],
                ProvisionedThroughput={'ReadCapacityUnits': 10, 'WriteCapacityUnits': 10})
    # Wait until the table exists.
    table.meta.client.get_waiter('table_exists').wait(TableName='vf-dictionary')
   
# Writing to dynamodb table with the required columns with error handling
def write_to_dynamo(rows):
   try:
      table = dynamodb.Table(tableName)
   except:
      print('Error loading DynamoDB table.')

   try:
      with table.batch_writer() as batch:
         for i in range(len(rows)):
            print(rows[i])
            batch.put_item(
               #Item=rows[i]
               Item={
                    'Index':i,
                    'Best':rows[i]['Best'],
                    'Word':rows[i]['Word'],
                    'FirstLetter':rows[i]['FirstLetter'],
                    'SecondLetter':rows[i]['SecondLetter'],
                    'ThirdLetter':rows[i]['ThirdLetter'],
                    'FouthLetter':rows[i]['FouthLetter'],
                    'FifthLetter':rows[i]['FifthLetter'],
                    'SixthLetter':rows[i]['SixthLetter'],
                    'SeventhLetter':rows[i]['SeventhLetter'],
                    'Length':rows[i]['Length']
        }
            )
   except Exception as err:
      print(err)
      print('Error executing batch_writer')