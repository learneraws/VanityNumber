import boto3
import json
import re
from datetime import datetime
from urllib.request import *

client = boto3.client('connect')
def lambda_handler(event, context):
    #Declatation Section
    now = datetime.now() 
    dt=now.strftime("%d%m%Y%H%M%S")    
    ConnectInstanceID=event['ResourceProperties']['ConnectInstanceID']
    LambdaArn=event['ResourceProperties']['VanityLambda']
    
    try:
        
        # Read contact flow for Lambda call, we will be creating child contact flow first and then main flow will be created as we have to use arn of child in our main flow.
        # Used python replace to update ARN of lambda function coming from input event which will be used in contact flow creation. 
        lambdacallflow = open('vf-LambdaCallFlow.json')
        datalambdacallflow = json.load(lambdacallflow)
        lambdacallflow_content=json.dumps(datalambdacallflow)
        lambdacallflow_content=re.sub("VANITYNUMBER_LAMBDAARN",LambdaArn,lambdacallflow_content)
        
        # Creation of child contact flow using api call, appended dt in the name of contcat flow so that lambda doesn't fail. We can add try catch here as well depending upon business case
        lambdaflowname='vf-Vanity-LambdaCallFlow'+dt
        print(lambdaflowname)
        responselambdaflow = client.create_contact_flow(InstanceId=ConnectInstanceID,
        Name=lambdaflowname,
        Type='CONTACT_FLOW',
        Content=lambdacallflow_content
            )
        
        # Fetch ARN of child contact flow which will be passed to Main flow
        responseLambdaArn=responselambdaflow['ContactFlowArn']
        
        # Read content of Main contact flow and load as json
        # Used python replace to update ARN of Child Lambda Flow
        mainflow = open('vf-MainFlow.json')
        datamainflow = json.load(mainflow)
        mainflow_content=json.dumps(datamainflow)        
        mainflow_content=re.sub("VANITYNUMBER_LAMBDA_CONTACTFLOW_ARN",str(responseLambdaArn),mainflow_content)
        mainflow_content=re.sub("VF-LambdaCall",str(lambdaflowname),mainflow_content)
        
        # Creation of child contact flow using api call, appended dt in the name of contcat flow so that lambda doesn't fail. We can add try catch here as well depending upon business case
        mainflowflowname='vf-Vanity-MainFlow'+dt
        print(mainflowflowname)
        response = client.create_contact_flow(InstanceId=ConnectInstanceID,
        Name=mainflowflowname,
        Type='CONTACT_FLOW',
        Content=mainflow_content
            )
        
        #Building response body to be sent
        response_data={"Message": "Resource update successful!"}
        response_body = json.dumps({
          "Status": "SUCCESS",
          "PhysicalResourceId": context.log_stream_name,
          "StackId": event['StackId'],
          "RequestId": event['RequestId'],
          "LogicalResourceId": event['LogicalResourceId'],
          "Data": response_data})
        response_body.encode('utf-8')
        responseArn=response['ContactFlowArn']
        
        response_bdy=response_body.encode('utf-8')
        opener = build_opener(HTTPHandler)
        request = Request(event['ResponseURL'], data=response_bdy)
        request.add_header('Content-Type', '')
        request.add_header('Content-Length', len(response_body))
        request.get_method = lambda: 'PUT'
        response = opener.open(request)
    except Exception as e:
        print(e)
        print("Error has occured, please check Logs for details")